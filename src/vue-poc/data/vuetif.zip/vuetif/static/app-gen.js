// generated 2018-01-12T12:45:49.997Z

// src: file:///C:/Users/andy/workspace/vuetif-tst/src/vuetif/components/qd-fullscreen.vue
Vue.component('qd-fullscreen',{template:` 
<a @click="toggle()" href="javascript:void(0);" title="Fullscreen toggle">
  <v-icon>{{ fullscreenIcon }}</v-icon>
  </a>
 `,
      
  data(){
    return {fullscreenIcon:"fullscreen"}
  },
  methods:{
    toggle(){
      this.$fullscreen.toggle()
      setTimeout(()=>{
        var state=this.$fullscreen.isInFullScreen()
        //console.log("FS",state);
        this.fullscreenIcon=state?"fullscreen_exit":"fullscreen"
        }, 1000);
    }
  }
}

      );
      
// src: file:///C:/Users/andy/workspace/vuetif-tst/src/vuetif/components/qd-link.vue
Vue.component('qd-link',{template:` 
 <a :href="href" :target="href"> {{href}}<v-icon>link</v-icon></a>
 `,
      
  props: ['href'],
  created:function(){
      console.log("qd-link");
    }
}

      );
      
// src: file:///C:/Users/andy/workspace/vuetif-tst/src/vuetif/components/qd-navlist.vue
Vue.component('qd-navlist',{template:` 
 <v-list dense="">
<template v-for="(item, i) in items">
  <v-layout row="" v-if="item.heading" align-center="" :key="i"> 
    <v-flex xs6="">
      <v-subheader v-if="item.heading">
        {{ item.heading }}
      </v-subheader>
    </v-flex>
    <v-flex xs6="" class="text-xs-center">
      <a href="#!" class="body-2 black--text">EDIT</a>
    </v-flex>
  </v-layout>
  <v-list-group v-else-if="item.children" v-model="item.model" no-action="">

      <v-list-tile :to="item.href" ripple="" slot="item">
       <v-list-tile-action>
          <v-icon>{{ item.icon }}</v-icon>
        </v-list-tile-action>
          <v-list-tile-title>
            {{ item.text }}
          </v-list-tile-title>
          <v-spacer></v-spacer>
        <v-list-tile-action>
          <v-icon>{{ item.model ? 'keyboard_arrow_up' : 'keyboard_arrow_down' }}</v-icon>
        </v-list-tile-action>
       
      </v-list-tile>
    <template v-for="(child, i) in item.children">
      <v-list-tile :to="child.href" :key="i" ripple="">
        <v-list-tile-action>
          <v-icon></v-icon>
        </v-list-tile-action>
        <v-list-tile-content>
          <v-list-tile-title>
             <v-icon>{{ child.icon }}</v-icon>&nbsp;{{ child.text }}
          </v-list-tile-title>
        </v-list-tile-content>
      </v-list-tile>
    </template>
  </v-list-group>
 
    <v-list-tile v-else="" :to="item.href" ripple="">
      <v-list-tile-action>
        <v-icon>{{ item.icon }}</v-icon>
      </v-list-tile-action>
      <v-list-tile-content>
        <v-list-tile-title>
          {{ item.text }}
        </v-list-tile-title>
      </v-list-tile-content>
    </v-list-tile>

</template>
</v-list>
 `,
      
  props: ['items']
}

      );
      
// src: C:\Users\andy\workspace\vuetif-tst\src\vuetif\components\filters.js
/**
 * vue filters
 */

//Define the date time format filter
Vue.filter("formatDate", function(date) {
    return moment(date).format("MMMM D, YYYY")
});
Vue.filter("fromNow", function(date) {
  return moment(date).fromNow()
});
Vue.filter('readablizeBytes', function (bytes,decimals) {
  if(bytes == 0) return '0 Bytes';
  var k = 1000,
      dm = decimals || 2,
      sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'],
      i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
});
Vue.filter("any", function(any) {
  return "ANY"
});
/**
 * Vue filter to round the decimal to the given place.
 * http://jsfiddle.net/bryan_k/3ova17y9/
 *
 * @param {String} value    The value string.
 * @param {Number} decimals The number of decimal places.
 */
Vue.filter('round', function(value, decimals) {
  if(!value) {
    value = 0;
  }

  if(!decimals) {
    decimals = 0;
  }

  value = Math.round(value * Math.pow(10, decimals)) / Math.pow(10, decimals);
  return value;
});

// src: file:///C:/Users/andy/workspace/vuetif-tst/src/vuetif/features/404.vue
const Notfound=Vue.extend({template:` 
 <v-container fluid="">
 Not found
 </v-container>
 `,
      
  data:  function(){
    return {
      message: 'bad route!'
      }
  },
  created:function(){
    console.log("notfound",this.$route.query.q)
  }
}

      );
      
// src: file:///C:/Users/andy/workspace/vuetif-tst/src/vuetif/features/home.vue
const Home=Vue.extend({template:` 

<v-card hover="" raised=""> 
<v-card-title class="pa-5 indigo">
<div class="display-1 white--text text-xs-center">VUE-POC</div>
<v-spacer></v-spacer>
  <v-speed-dial v-model="fab" hover="" right="" direction="bottom" transition="slide-y-reverse-transition">
      <v-btn slot="activator" class="blue darken-2" dark="" fab="" hover="" v-model="fab">
        <v-icon>account_circle</v-icon>
        <v-icon>close</v-icon>
      </v-btn>
      <v-btn fab="" dark="" small="" class="green">
        <v-icon>edit</v-icon>
      </v-btn>
      <v-btn fab="" dark="" small="" class="indigo">
        <v-icon>add</v-icon>
      </v-btn>
      <v-btn fab="" dark="" small="" class="red">
        <v-icon>delete</v-icon>
      </v-btn>
    </v-speed-dial>
 </v-card-title> 

 <v-card-text>
 
<p>
	links
</p>
<ul>

<li><router-link :to="{path:'files', query:{url:'/vue-poc/'}}">vue-poc files</router-link></li>
<li><router-link :to="{path:'database', query:{url:'/vue-poc/'}}">vue-poc db</router-link></li>
	<li><a href="/doc/#/data/app/vue-poc" target="new">doc</a></li>
	<li><a href="/dba" target="new">DBA app</a></li>
	<li><a href="/vue-poc/ui/database?url=%2Fvue-poc%2F" target="new">db</a></li>
<li><router-link :to="{path:'files', query:{url:'/vue-poc/features/images/'}}">vue-poc image tasks</router-link></li>
</ul>

<v-btn floating="floating"> <v-icon>add</v-icon> 
</v-btn> <qd-link href="/dba">REPLACED</qd-link> 
  
    </v-card-text> 
</v-card> 
	 `,
      
    data:  function(){
      return { 
              fab: false
      }
  }
  }

      );
      
// src: C:\Users\andy\workspace\vuetif-tst\src\vuetif\router.js
// vue-poc application routes
const router = new VueRouter({
  base:"/vuetif/ui/",
  mode: 'history',
  //
  scrollBehavior (to, from, savedPosition) {
    if (savedPosition) {
      return savedPosition
    } else if (to.hash) {
      return { selector: to.hash, behavior: 'smooth' }

    } else {
      return { x: 0, y: 0 }
    }
  },
  routes: [
    { path: '/', component: Home, meta:{title:"Home"} },
   
    { path: '*', component: Notfound,meta:{title:"Page not found"} }
  ],
});
router.afterEach(function(route) {
  document.title = (route.meta.title?route.meta.title:"") + " Vuetif";
});

router.beforeEach((to, from, next) => {
  if (to.matched.some(record => record.meta.requiresAuth)) {
    // this route requires auth, check if logged in
    // if not, redirect to login page.
    if ("admin"==Auth.permission) {
      next({
        path: '/login',
        query: { redirect: to.fullPath }
      })
    } else {
      next()
    }
  } else {
    next() // make sure to always call next()!
  }
});

// src: C:\Users\andy\workspace\vuetif-tst\src\vuetif\app.vue
const Vuepoc=Vue.extend({template:` 
 <v-app id="app" :dark="dark">
  <v-navigation-drawer absolute="" v-model="showNotifications" right="" :disable-route-watcher="true" app="" width="500">
    <v-card>
         <v-toolbar class="amber white--text">
                <v-toolbar-title>Notifications </v-toolbar-title>
          <v-spacer></v-spacer>
          <v-btn @click="showNotifications = false" icon=""><v-icon>close</v-icon></v-btn>
          </v-toolbar>
          <v-card-text>
        <v-list three-line="">
          <template v-for="msg in $notification.messages">
           <v-list-tile avatar="" v-bind:key="msg.index" @click="">
              <v-list-tile-avatar>
                   <v-icon color="red">swap_horiz</v-icon>
              </v-list-tile-avatar>
              <v-list-tile-content>
              <v-tooltip>
                <v-list-tile-title slot="activator">{{ msg.created | fromNow("from") }}</v-list-tile-title>
                <span v-text="msg.created"></span>
                </v-tooltip>
                <v-list-tile-sub-title v-html="msg.text"></v-list-tile-sub-title>
              </v-list-tile-content>
              <v-list-tile-action>
               <v-list-tile-action-text>{{ msg.index }}</v-list-tile-action-text>
              </v-list-tile-action>
            </v-list-tile>
           </template>
         </v-list>
      </v-card-text>
      </v-card>
</v-navigation-drawer>
 <v-navigation-drawer app="" :mini-variant.sync="mini" v-model="drawer" absolute="" :disable-route-watcher="true" :enable-resize-watcher="true">
  <v-list class="pa-0">

          <v-list-tile avatar="" tag="div">
            <v-list-tile-avatar>
              <v-btn icon="" @click="session">
              <img src="/vue-poc/ui/quodatum.gif">
              </v-btn>
            </v-list-tile-avatar>
            <v-list-tile-content>
              <v-list-tile-title>Vue PoC</v-list-tile-title>
            </v-list-tile-content>
            <v-list-tile-action>
              <v-btn icon="" @click.stop="mini = !mini">
                <v-icon>chevron_left</v-icon>
              </v-btn>
            </v-list-tile-action>
          </v-list-tile>

      </v-list>
    <qd-navlist :items="items"></qd-navlist>
 </v-navigation-drawer>
  
 <v-toolbar class="indigo" app="" dark="">
  <v-toolbar-side-icon @click.stop="drawer = !drawer"></v-toolbar-side-icon>  
  <v-toolbar-title class="hidden-sm-and-down">{{$route.meta.title}}</v-toolbar-title>
   <v-menu offset-x="" :close-on-content-click="false" :nudge-width="200" v-model="frmFav">
      <v-btn slot="activator" @click="frmFav = !frmFav" icon="" flat="" title="Bookmark this page">
       <v-icon>star_border</v-icon>
       </v-btn>

            <v-card style="width:400px;">
            <v-toolbar class="amber"> 
        <v-card-title>
            Bookmark this page
          </v-card-title>
          </v-toolbar>
         <v-card-text>
         <h6>{{$route.meta.title}}</h6>
            <v-select v-model="tags" label="tags" chips="" tags="" :items="taglist"></v-select>
           </v-card-text>
        <v-card-actions>
            <v-spacer></v-spacer>
            <v-btn color="primary" flat="" @click.stop="frmFav=false">Cancel</v-btn>
            <v-btn color="primary" flat="" @click.stop="favorite();frmFav=false">Save</v-btn>
          </v-card-actions>
        </v-card>
   </v-menu>
  <v-spacer></v-spacer>
  <v-text-field prepend-icon="search" label="Search..." v-model="q" hide-details="" single-line="" dark="" @keyup.enter="search"></v-text-field>
  <v-spacer></v-spacer>
  
   <v-menu left="" transition="v-fade-transition">
      <v-btn dark="" icon="" slot="activator">
        {{$auth.user}}
      </v-btn>
     
          <v-list>
        
              <v-list-tile @click="logout()">
                <v-list-tile-title>logout</v-list-tile-title>
              </v-list-tile>
               <v-list-tile>
                <v-list-tile-title>permission: {{$auth.permission}}</v-list-tile-title>
              </v-list-tile>
            
          </v-list>
      </v-menu>
      <qd-fullscreen></qd-fullscreen>
       <v-btn @click="showNotifications = ! showNotifications" icon="" flat="" title="Notifications">
       <v-icon>notifications</v-icon>
   </v-btn>
</v-toolbar>
 
 <v-content> 
 <v-alert color="error" value="true" dismissible="" v-model="alert.show">
      <pre style="overflow:auto;">{{ alert.msg }}</pre>
    </v-alert>   
    <transition name="fade" mode="out-in">
      <router-view class="view ma-3"></router-view>
      </transition>
  </v-content>

</v-app>
 `,
      
  router,
  data:function(){return {
    q: "",
    status: {},
    drawer: true,
    showNotifications: false,
    mini: false,
    dark: false,
    alert: {show:false,msg:"Hello"},
    frmFav: false,
    tags: [],
    taglist: [
      'todo',
      'find',
      'some',
      'good',
      'tags'
    ],
    items: [
      {href: '/',text: 'Home', icon: 'home'    },
      {
        icon: 'input',
        text: 'Actions' ,
        model: false,
        children: [
      {href: '/eval',text: 'Query',icon: 'play_circle_outline'},
      {href: '/edit',text: 'Edit',icon: 'mode_edit'},
      {href: '/validate',text: 'Validate',icon: 'playlist_add_check'},
      {href: '/transform',text: 'XSLT Transform',icon: 'forward'},
      {href: '/tasks',text: 'Tasks',icon: 'update'}
      ]},
      {
        icon: 'folder_open',
        text: 'Collections' ,
        model: false,
        children: [
       {href: '/database', text: 'Databases',icon: 'developer_mode' },
       {href: '/files', text: 'File system',icon: 'folder' },
      {href: '/history',text: 'history',icon: 'history'}
      ]},
      {
        icon: 'memory',
        text: 'Models' ,
        model: false,
        children: [
          {href: '/namespace', text: 'Namespaces',icon: 'label' },
          {href: '/entity', text: 'Entities',icon: 'redeem' },
      ]},
      {
        icon: 'cast_connected',
        text: 'Server' ,
        model: false,
        children: [
          {href: '/jobs',text: 'Running jobs',icon: 'dashboard'},   
          {href: '/logs',text: 'Server logs',icon: 'dns'},
          {href: '/timeline',text: 'Time line',icon: 'timelapse'},
          {href: '/server/users',text: 'Users',icon: 'supervisor_account'},
          {href: '/server/repo',text: 'Server code repository',icon: 'local_library'},
          {href: '/ping',text: 'Ping',icon: 'update'}
      ]},
      {
        icon: 'camera_roll',
        text: 'Images' ,
        model: false,
        children: [
          {href: '/images/item',text: 'Collection',icon: 'photo_camera'},
          {href: '/images/keywords',text: 'Keywords',icon: 'label'},
          {href: '/images/dates',text: 'Date taken',icon: 'date_range'},
          {href: '/images/thumbnail',text: 'Thumbnail',icon: 'touch_app'},
          {href: '/images/people',text: 'People',icon: 'people'},
          {href: '/map',text: 'Map',icon: 'place'}, 
          {href: '/images/report',text: 'Reports',icon: 'report'}
          ]},
      {
        icon: 'more_horiz',
        text: 'More' ,
        model: false,
        children: [
      {href: '/session',text: 'Session',icon: 'person'}, 
      {href: '/select',text: 'Select',icon: 'extension'},
      {href: '/puzzle',text: 'Puzzle',icon: 'extension'},
      {href: '/svg',text: 'SVG',icon: 'extension'},
      {href: '/form',text: 'Forms',icon: 'format_list_bulleted'  },
      {href: '/tabs',text: 'Tabs',icon: 'switch_camera'}
      ]},
      
      {href: '/settings',text: 'Settings',icon: 'settings'  },
      {href: '/about',text: 'About (v1.0.1)' , icon: 'help'    }, 
    ]

  }},
  methods: {
      session(){
        this.$router.push({path: '/session'})
      },
      search(){
        this.$router.push({path: '/search',query: { q: this.q }})
      },
      logout(){
        HTTP.get("logout").then(r=>{
          alert("logout")
        }) 
      },
      showAlert(msg){
        this.alert.msg=moment().format()+" "+ msg
        this.alert.show=true
      },
      onDark(dark){
        this.dark=dark
      },
      favorite(){
        alert("@TODO")
      }
  },

  created(){
    console.log("create-----------")
    var that=this
    this.$on("theme",this.onDark)
    Vue.config.errorHandler = function (err, vm, info) {
  // handle error
  // `info` is a Vue-specific error info, e.g. which lifecycle hook
        console.error(err, vm, info);
        var msg=JSON.stringify(err)
        that.showAlert("vue error:\n"+msg)
        //alert("vue error");
   };
    
    HTTP.get("status")
    .then(r=>{
      console.log("status",r.data)
      Object.assign(Auth,r.data)
      this.$forceUpdate()
    }) 
  },
  beforeDestroy(){
    console.log("destory-----------")
    
  }
  }

      );
      
// src: C:\Users\andy\workspace\vuetif-tst\src\vuetif\core.js
// base -----------------------

const AXIOS_CONFIG={
    baseURL: "/vuetif/api/",
    headers: {
      'X-Custom-Header': 'vue-poc',
      accept: 'application/json'
    },
    paramsSerializer: function(params) {
      return Qs.stringify(params)
    }
  };

// time requests

// Add a response interceptor
axios.interceptors.response.use(function (response) {
    // Do something with response data
  console.log("AXIOS",response);
    return response;
  }, function (error) {
    // Do something with response error
    return Promise.reject(error);
  });

// errors displayed by interceptor
const HTTP = axios.create(AXIOS_CONFIG);
HTTP.interceptors.request.use((config) => {
  config.qdStartTime=performance.now();
  return config;
});
HTTP.interceptors.response.use((response) => {
  // Do something with response data
  if(response.config && response.config.qdStartTime){
    var s=Math.floor(performance.now() - response.config.qdStartTime);
    console.log("interceptors time:",s, response.config.url);
    Notification.add(s +" "+ response.config.url );
  }
  return response;
});

// errors hidden
const HTTPNE = axios.create(AXIOS_CONFIG);
const axios_json={ headers: {accept: 'application/json'}};


// Authorization Object
const Auth={
    user:"guest",
    permission:null,
    install: function(Vue){
        Object.defineProperty(Vue.prototype, '$auth', {
          get () { return Auth }
      })  }
};
Vue.use(Auth);

//Notification Object
const Notification={
    messages:[],
    nextId: 0,
    add(msg){
      var data={
          text: msg,
          index: ++this.nextId,
          created: new Date()
      };
      this.messages.unshift(data);
      this.messages.length = Math.min(this.messages.length, 30)


    },
    install(Vue){
        Object.defineProperty(Vue.prototype, '$notification', {
          get () { return Notification }
      })  }
};
Vue.use(Notification);

// Mimetype info
const MimeTypes={
      "text/xml":"xml",
      "application/xml":"xml",
      "application/xquery":"xquery",
      "text/ecmascript":"javascript",
      "application/sparql-query":"sparql",
      "text/html":"html",
      "text/turtle":"turtle",
      "text/css":"css",
      "image/svg+xml":"svg"
};

// Settings read and write list clear
localforage.config({
  name: 'vuepoc'
});
// https://vuejs.org/v2/guide/state-management.html
var settings = {
    debug: false,
    getItem (key) {
      if (this.debug) console.log('getItem',key);
      return localforage.getItem(key)
        .then(value => {
          //console.log('GET setting', key,value);
          return value;
     
        }).catch(err => {
          console.log('GET failed');

      });
    },
    setItem (key,value) {
      if (this.debug) console.log('setItem',key,value);
      return localforage.setItem(key, value) 
      .then(value => {
        //console.log('SET ',key, value);
        return value
        
      }).catch(err => {
        console.log('set failed');
      });
   },
    keys(){
      return localforage.keys() // returns array of keys 
 
  },
  clear(){
    localforage.clear()
  }
};

// error help 
// https://stackoverflow.com/questions/18391212/is-it-not-possible-to-stringify-an-error-using-json-stringify/18391400#18391400
if (!('toJSON' in Error.prototype))
  Object.defineProperty(Error.prototype, 'toJSON', {
      value: function () {
          var alt = {};

          Object.getOwnPropertyNames(this).forEach(function (key) {
              alt[key] = this[key];
          }, this);

          return alt;
      },
      configurable: true,
      writable: true
  });

//Returns a function, that, as long as it continues to be invoked, will not
//be triggered. The function will be called after it stops being called for
//N milliseconds. If `immediate` is passed, trigger the function on the
//leading edge, instead of the trailing. https://gist.github.com/nmsdvid/8807205
function debounce(func, wait, immediate) {
 var timeout;
 return function() {
     var context = this, args = arguments;
     clearTimeout(timeout);
     timeout = setTimeout(function() {
         timeout = null;
         if (!immediate) func.apply(context, args);
     }, wait);
     if (immediate && !timeout) func.apply(context, args);
 };
};

// https://stackoverflow.com/questions/36672561/how-to-exit-fullscreen-onclick-using-javascript
const Fullscreen={
    isInFullScreen(){
      return (document.fullscreenElement && document.fullscreenElement !== null) ||
      (document.webkitFullscreenElement && document.webkitFullscreenElement !== null) ||
      (document.mozFullScreenElement && document.mozFullScreenElement !== null) ||
      (document.msFullscreenElement && document.msFullscreenElement !== null);
    },
    toggle(){
      var docElm = document.documentElement;
      if (!this.isInFullScreen()) {
          if (docElm.requestFullscreen) {
              docElm.requestFullscreen();
          } else if (docElm.mozRequestFullScreen) {
              docElm.mozRequestFullScreen();
          } else if (docElm.webkitRequestFullScreen) {
              docElm.webkitRequestFullScreen();
          } else if (docElm.msRequestFullscreen) {
              docElm.msRequestFullscreen();
          }
      } else {
          if (document.exitFullscreen) {
              document.exitFullscreen();
          } else if (document.webkitExitFullscreen) {
              document.webkitExitFullscreen();
          } else if (document.mozCancelFullScreen) {
              document.mozCancelFullScreen();
          } else if (document.msExitFullscreen) {
              document.msExitFullscreen();
          }
      }
    },
    install: function(Vue){
      Object.defineProperty(Vue.prototype, '$fullscreen', {
        get () { return Fullscreen }
    })  }
};
Vue.use(Fullscreen);

Vue.use(Vuetify);
new Vuepoc().$mount('#app')

